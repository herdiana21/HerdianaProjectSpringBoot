package HerdianaProjectSpringBoot.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import HerdianaProjectSpringBoot.Dao.TabunganDao;
import HerdianaProjectSpringBoot.Model.TabunganModel;

@RestController
@RequestMapping("/bank")
public class TabunganController {
	@Autowired
	TabunganDao tabunganDao;
	
	@PostMapping("/Save")
	public TabunganModel SaveTabungan(@Valid @RequestBody TabunganModel model) {
		return tabunganDao.save(model);
		
	}
	
	@GetMapping("/getAll")
	public List<TabunganModel> getAllTabungan(){
		return tabunganDao.findAll();
	}
	
	@GetMapping("/getTabunganById/{id}")
	public ResponseEntity<TabunganModel> getTabunganById(@PathVariable(value="id") Long id) {
		TabunganModel b=tabunganDao.getFindOne(id);
		if(b==null) {
			return ResponseEntity.notFound().build();
		}else {
			return ResponseEntity.ok().body(b);
		}
	}
	
	@GetMapping("tabunganByNik/{nik}")
	public List<TabunganModel> getTabunganByNik(@PathVariable(value="nik") String nik){
		return tabunganDao.findByNik(nik);	
	}
	@GetMapping("/saldo/{nik}")
	public ResponseEntity<TabunganModel> getTabungan(@PathVariable(value="nik") String nik) {
		TabunganModel b=tabunganDao.getFindSaldo(nik);
		if(b==null) {
			return ResponseEntity.notFound().build();
		}else {
			return ResponseEntity.ok().body(b);
		}
	}
	
	@DeleteMapping("DeleteTabungan/{id}")
	public ResponseEntity<TabunganModel> deleteTabungan(@PathVariable(value="id")Long id){
		TabunganModel b=tabunganDao.getFindOne(id);
		if(b==null) {
			return ResponseEntity.notFound().build();
		}else {
			tabunganDao.deleteTabungan(id);;
			return  ResponseEntity.ok().build();
		}
	}
	
	@PutMapping("UpdateTabungan/{id}")
	public ResponseEntity<TabunganModel> updateSaldo (@PathVariable(value="id") Long id,@Valid @RequestBody TabunganModel tabungan){
		TabunganModel b=tabunganDao.getFindOne(id);
		if(b==null) {
			return ResponseEntity.notFound().build();
		}else {
			b.setSaldo(b.getSaldo()-b.getKredit()+b.getDebet());
			b.setKredit(tabungan.getKredit());
			b.setDebet(tabungan.getDebet());
		
			
			TabunganModel bResult=tabunganDao.Update(b);
			return ResponseEntity.ok().body(bResult);
		}

	}
}
